define(['jquery','template','rq_index']),function($,template,Yemaijui){
  return {
    init:function(){
      var rq_index = new Yemaijui();
      return this
      // $('#top').load('../html/header.html');
      // $('#footer').load('../html/footer.html');
      // $('#mui_mbar').load('../html/reight_tabs.html');
    },
  }
}
